# template

This template should help get you started developing with Vue 3 in Vite.

## Installation
Here's a one-liner to download, install and run the template:
```
sh -c "$(curl -fsSL https://raw.githubusercontent.com/kaangiray26/vuejs-template/main/install.sh)"
```